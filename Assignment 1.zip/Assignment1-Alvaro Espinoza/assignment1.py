
################################################################################
#                           Assignment 1 – Basic Calculations                  #
#                                                                              #
# PROGRAMMER:       Alvaro-Espinoza                                            #
# CLASS:            CG120                                                      #
# ASSIGNMENT:       Assignment assig-#1                                        #
# INSTRUCTOR:       Dean Zeller                                                #
# TA:               Robert Carver                                              #
# SUBMISSION DATE:  08-31-2018                                                 #
#                                                                              #
# DESCRIPTION:                                                                 #
# This program will perform basic calculations such as finding the average     #
# and sum of three integers that the user will provide.                        #
# COPYRIGHT:                                                                   #
# This program is (c) 2018 Alvaro-Espinoza and Dean Zeller. This is original   #
# work, with the exception of @JohnReqmash/- Python's Typewriter Effect        #
################################################################################
import time 
import sys 


 
words= ["Welcome to Assignment 1, Basic Calculations"]

for typing in words[0]:
    time.sleep(0.045) 
    sys.stdout.write(typing)
    sys.stdout.flush()
    
print("")
print("")
name= input("Please enter your name => ")
print("Hello,",name)
import time
print("")
################################################################################
# Introduction                                                                 #
################################################################################
time.sleep(2)
print("Introduction:")
words=["This program will calculate basic statistics on three integer numbers.  It will run in three phases:"]
for typing in words[0]:
    time.sleep(0.045) 
    sys.stdout.write(typing)
    sys.stdout.flush()

print("")
print("    Phase 1-Gather input from user")
print("    Phase 2-Calculate sum and average")
print("    Phase 3-Output results")
print("")
################################################################################
# Phase 1 -- Gather input from user                                            #
################################################################################
time.sleep(5)
print("Phase 1:Gather user input")
print("-------------------------")
time.sleep(2)
words=["Please enter three numbers.  Only integer values (whole numbers), as error-checking has not yet been implemented."]
for typing in words[0]:
    time.sleep(0.045) 
    sys.stdout.write(typing)
    sys.stdout.flush()
print("")
number1= int(input("    First number=>")) 
number2= int(input("    Second number=>"))
number3= int(input("    Third number=>"))
print("")
print("Number entered:",number1, number2, number3)

words=["Phase 1 complete"]
for typing in words[0]:
    time.sleep(0.045) 
    sys.stdout.write(typing)
    sys.stdout.flush()
print("")
print("")
################################################################################
# Phase 2 -- Perform Calculations                                              #
################################################################################
time.sleep(2.5)
print("Phase 2: Perform Calculations")
print("-----------------------------")
time.sleep(1)
print("    Calculated sum")
time.sleep(1)
print("    Calculated average")
time.sleep(1)
words=["Phase 2 complete"]
for typing in words[0]:
    time.sleep(0.045) 
    sys.stdout.write(typing)
    sys.stdout.flush()
print("")
print("")
################################################################################
# Phase 3 -- Output table                                                      #
################################################################################
time.sleep(2.5)
print("Phase 3: Output table")
print("---------------------")
time.sleep(2)
print("Data:    ",number1, number2, number3)
Sum=(number1+number2+number3)
time.sleep(1)
print("Sum:     ",Sum)
time.sleep(1)
print("Average: ",Sum/3)
print("")
time.sleep(1.5)
words=["Phase 3 complete"]
for typing in words[0]:
    time.sleep(0.045) 
    sys.stdout.write(typing)
    sys.stdout.flush()
print("")
################################################################################
# Ending Message -- Exiting program                                            #
################################################################################
words=["Exiting program"]
for typing in words[0]:
    time.sleep(0.045) 
    sys.stdout.write(typing)
    sys.stdout.flush()

