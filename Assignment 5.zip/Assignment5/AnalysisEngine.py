################################################################################
#                           Standard Deviation                                 #
#                                                                              #
# PROGRAMMER:       Alvaro Espinoza                                            #
# CLASS:            CG120                                                      #
# ASSIGNMENT:       Assignment 5                                               #
# INSTRUCTOR:       Dean Zeller                                                #
# TA:               Robert Carver                                              #
# SUBMISSION DATE:  10/19/2018                                                 #
#                                                                              #
# DESCRIPTION:                                                                 #
# This is the object definition template for the Analysis Engine.  It          #
# contains attributes and methods to be called upon by Analysis Engine Tester. #
#                                                                              #
#                                                                              #
# COPYRIGHT:                                                                   #
# This program is (c) 2018 Alvaro Espinoza,and Dean Zeller. This is original   #
# work, with the exception of Daniel Klimchuk's median algorithm.              #
################################################################################
import statistics

class AnalysisEngine:

    #####################################################################
    # __init__                                                          #
    #                                                                   #
    # purpose:                                                          3
    #     - initialize the attributes to default values                 #
    # parameters: none                                                  #
    # return value: none                                                #
    #####################################################################
    def __init__ (self):
        self.leader   = ""
        self.title    = ""
        self.data     = []
        self.sum      = 0
        self.average  = 0.0
        self.variance = 0.0
        self.stdev    = 0.0
        self.harmonicMean = 0.0
        self.min      = 0.0
        self.max      = 0.0
        self.median   = 0.0
        self.pvariance = 0.0
        self.pstdev   = 0.0
        

    #####################################################################
    # introduction                                                      #
    #                                                                   #
    # purpose:                                                          #
    #     - accept user input for user and study name                   #
    #     - display instructions for user                               #
    # parameters: none                                                  #
    # return value: none                                                #
    #####################################################################
    def introduction(self):
        print("Welcome to Assignment 5, More Processing")
        print()
        self.title = input("Enter the title of the study => ")
        print("Study title set to",self.title)
        print()
        self.leader = input("Enter the head of research for this study => ")
        print("Hello,",self.leader+".")
        print("")
        print("Introduction:")
        print("This program will calculate the standard deviation for")
        print("a list of values entered by the user.  It will run in")
        print("three phases:")
        print("    Phase 1 - Gather input from user")
        print("    Phase 2 - Calculate sum, average, variance, and stdev")
        print("    Phase 3 - Output results")
        print()
        
    #####################################################################
    # gatherData                                                        #
    #                                                                   #
    # purpose:                                                          #
    #     - accept user input for the self.data attribute               #
    # parameters: none                                                  #
    # return value: none                                                #
    #####################################################################
    def gatherData(self):
        print("Phase 1:  Gather user input")
        print("---------------------------")
        print("To enter the data correctly, the program needs to know how many numbers are in the dataset.")
        while(True):
            try:
                response=input("    Size of dataset => ")
                size=int(response)
                break
            except ValueError:
                print("   ",response,"is not an integer value")
                print("    Please enter an integer value.")
        print("    You entered",size)
        print("    Data will have",size, "elements, indexed 0 through",size-1,".")
        print("")


        print("Enter integer and floating-point values:")
        for i in range(size):
            while(True):
                try:
                    response=(input("  Index "+str(i)+(" => ")))
                    num = float(response)
                    break
                except ValueError:
                    print(response,"is not a floating-point value.")
                    print("Please enter a floating-point value.")
            self.data.append(num)
       
                
        print("Data entered:",self.data)
        print("Phase 1 Complete")
                    


    #####################################################################
    # calcSum                                                           #
    #                                                                   #
    # purpose:                                                          #
    #     - calculate and print the sum of self.data                    #
    # parameters: none                                                  #
    # return value: none                                                #
    #####################################################################
    def calcSum(self):
        self.sum=0
        for n in self.data:
            self.sum += n
        print("    Calculated sum ("+str(self.sum)+")")

    #####################################################################
    # calcAverage                                                       #
    #                                                                   #
    # purpose:                                                          #
    #     - calculate and print the average of self.data                #
    # parameters: none                                                  #
    # return value: none                                                #
    #####################################################################
    def calcAverage(self):
        self.average=self.sum/len(self.data)
        print("    Calculated average ("+str(self.average)+")")

    #####################################################################
    # calcVariance                                                      #
    #                                                                   #
    # purpose:                                                          #
    #     - calculate and print the variance of self.data               #
    # parameters: none                                                  #
    # return value: none                                                #
    #####################################################################
    def calcVariance(self):
        top=0.0
        for d in self.data:
            top += (d-self.average)**2
        self.variance= top/(len(self.data)-1)
        print("    Calculated variance ("+str(self.variance)+")")

    #####################################################################
    # calcStdev                                                         #
    #                                                                   #
    # purpose:                                                          #
    #     - calculate and print the (sample) standard deviation of      #
    #       self.data                                                   #
    # parameters: none                                                  #
    # return value: none                                                #
    #####################################################################
    def calcStdev(self):
        self.stdev=(self.variance)**.5
        print("    Calculated standard deviation ("+str(self.stdev)+")")

    #####################################################################
    # calcHarmonicMean                                                  #
    #                                                                   #
    # purpose:                                                          #
    #     - calculate and print the Harmonic Mean of self.data          #
    #                                                                   #
    # parameters: none                                                  #
    # return value: none                                                #
    #####################################################################
    def calcHarmonicMean(self):
        bottom=0.0
        for n in self.data:
            bottom += 1/n
            self.harmonicMean = len(self.data)/ bottom
        print("    Calculated harmonic mean ("+str(self.harmonicMean)+")")
        

    #####################################################################
    # calcMin                                                           #
    #                                                                   #
    # purpose:                                                          #
    #     - calculate and print the minimum of self.data                #
    #                                                                   #
    # parameters: none                                                  #
    # return value: none                                                #
    #####################################################################
    def calcMin(self):
        self.min=999999999999999999999999999999
        for num in self.data:
            if num < self.min:
                self.min = num
        print("    Calculated min ("+str(self.min)+")")

    #####################################################################
    # calcMax                                                           #
    #                                                                   #
    # purpose:                                                          #
    #     - calculate and print the maximum of self.data                #
    #                                                                   #
    # parameters: none                                                  #
    # return value: none                                                #
    #####################################################################
    def calcMax(self):
        self.max=-99999999999999999999999999999999
        for num in self.data:
            if num > self.max:
                self.max = num
        print("    Calculated max ("+str(self.max)+")")

    #####################################################################
    # calcMedian                                                        #
    #                                                                   #
    # purpose:                                                          #
    #     - calculate and print the median of self.data                 #
    #                                                                   #
    # parameters: none                                                  #
    # return value: none                                                #
    #####################################################################
    def calcMedian(self):
        self.data.sort()
        length = len(self.data)
        if(length % 2 ==0):
            self.median = (self.data[(length)//2] + self.data[(length)//2-1]) /2
        else:
            self.median = self.data[(length-1)//2]
        print("    Calculated median ("+str(self.median)+")")

    #####################################################################
    # calcPvariance                                                     #
    #                                                                   #
    # purpose:                                                          #
    #     - calculate and print the population variance of self.data    #
    # parameters: none                                                  #
    # return value: none                                                #
    #####################################################################
    def calcPvariance(self):
        top=0.0
        for d in self.data:
            top += (d-self.average)**2
        self.pvariance= top/(len(self.data))
        print("    Calculated population variance ("+str(self.pvariance)+")")

    #####################################################################
    # calcPstdev                                                        #
    #                                                                   #
    # purpose:                                                          #
    #     - calculate and print the population standard deviation of    #
    #       self.data                                                   #
    # parameters: none                                                  #
    # return value: none                                                #
    #####################################################################
    def calcPstdev(self):
        self.pstdev=(self.pvariance)**.5
        print("    Calculated standard deviation ("+str(self.pstdev)+")")

    
    #####################################################################
    # performCalculations                                               #
    #                                                                   #
    # purpose:                                                          #
    #     - perform all calculations, with appropriate header           #
    # parameters: none                                                  #
    # return value: none                                                #
    #####################################################################
    def performCalculations(self):
        print("")
        print("Phase 2:  Perform Calculations")
        print("------------------------------")
        self.calcSum()
        self.calcAverage()
        self.calcVariance()
        self.calcStdev()
        self.calcHarmonicMean()
        self.calcMin()
        self.calcMax()
        self.calcMedian()
        self.calcPvariance()
        self.calcPstdev()
        print("Phase 2 complete")
        print()

    #####################################################################
    # printReport                                                       #
    #                                                                   #
    # purpose:                                                          #
    #     - print a summary report of the study                         #
    # parameters: none                                                  #
    # return value: none                                                #
    #####################################################################
    def printReport(self):
        print("Phase 3:  Output table")
        print("----------------------")
        print("")
        horizLine = ("+---------------------------------------------------------+")
        print(horizLine)
        studyname = "Study name: "
        print("| %-1s %-42s |" %(studyname,self.title))
        by = "By: "
        print("| %-1s %-50s |" %(by,self.leader))
        print(horizLine)
        calculated = "calculated"
        actual = "actual"
        print("|%40s %11s     |" %(calculated, actual))
        SUM = "Sum:"
        MEAN = "Mean:"
        VARIANCE = "Variance:"
        STDEV = "Standard Deviation:"
        print("| %-31s %-12.3f %-10.3f |" %(SUM,self.sum,self.sum))
        print("| %-31s %-12.3f %-10.3f |" %(MEAN,self.average,self.average))
        print("| %-31s %-12.3f %-10.3f |" %(VARIANCE,self.variance,self.variance))
        print("| %-31s %-12.3f %-10.3f |" %(STDEV,self.stdev,self.stdev))
        print("| %-31s %-12.3f %-10.3f |" %("Harmonic Mean:",self.harmonicMean,self.harmonicMean))
        print("| %-31s %-12.3f %-10.3f |" %("Min:",self.min,self.min))
        print("| %-31s %-12.3f %-10.3f |" %("Max:",self.max,self.max))
        print("| %-31s %-12.3f %-10.3f |" %("Median:",self.median,self.median))
        print("| %-31s %-12.3f %-10.3f |" %("Population Variance:",self.pvariance,self.pvariance))
        print("| %-31s %-12.3f %-10.3f |" %("Population Stdev:",self.pstdev,self.pstdev))
        print(horizLine)
        print("")
        print("Phase 3 complete")
        print()

    # compareResultsReport method and documentation, from step 10

    #####################################################################
    # closing                                                           #
    #                                                                   #
    # purpose:                                                          #
    #     - print closing remarks                                       #
    # parameters: none                                                  #
    # return value: none                                                #
    #####################################################################
    def closing(self):
        print("Exiting study: ",self.title)
        print("Goodbye!")
