################################################################################
#                           Genie movable object                               #
#                                                                              #
# PROGRAMMER:       Alvaro Espinoza                                            #      
# CLASS:            CG120                                                      #
# ASSIGNMENT:       Assignment 7                                               #
# INSTRUCTOR:       Dean Zeller                                                #
# TA:               Robert Carver                                              #
# SUBMISSION DATE:  November 16, 2018                                          #                                                                              #
# DESCRIPTION:                                                                 #
# This is the definition for a genie movable object.                           #
#                                                                              #
# COPYRIGHT:                                                                   #
# This program is (c) 2018 Alvaro Espinoza and Dean Zeller. This is original   #
# work, without use of outside sources.                                        #
################################################################################
from tkinter import *
import random

class genie:

    #####################################################################
    # __init__                                                          #
    #                                                                   #
    # purpose:                                                          #
    #     initialize attributes to parameters                           #
    # parameters:                                                       #
    #     canvas -- the canvas to draw the genie                        #
    #     name   -- name of the genie, used as a tag for animation      #
    #     bodyColor -- the color of the genie instance head             #
    #     accesoryColor -- the color of the genie instance body         #
    # return value: none                                                #
    #####################################################################
    def __init__ (self, canvas, name="Blank", bodyColor = "yellow", accessoryColor = "black"):
        self.c = canvas
        self.name = name
        self.center = 0
        self.middle = 0
        self.name = name
        self.bodyColor = bodyColor
        self.accessoryColor = accessoryColor

    #####################################################################
    # draw                                                              #
    #                                                                   #
    # purpose:                                                          #
    #     draws the genie instance with its initial location and colors #
    # parameters:                                                       #
    #     none                                                          #
    # return value: none                                                #
    #####################################################################
    def draw(self):
        # define coordinates
        # currently all coordinates are hardcoded
        self.center = 200
        self.middle = 112
        bodyCoords = ( (212.5,150),(275,262.5),(150,262.5) )

        rightlegCoords = ( (235,262.5),(235,282.5) )
        rightleg1Coords = ( (235,252.5),(215,297.5) )
        rightleg2Coords = ( (225,297.5),(227.5,310) )

        leftlegCoords = ( (190,262.5),(190,282.5) )
        leftleg1Coords = ( (189.5,252.5),(210,297.5) )
        leftleg2Coords = ( (200,297.5),(197.5,310) )

        
        #hat
        hatCoords = ( (205,150.5),(220,150.5),(220,100),(205,100) )
        hat2Coords = ( (196,151.5),(229,151.5) )
        bowtieCoords = ( (210,230),(215,235) )
        bowtie2Coords = ( (200,226),(200,239),(225,226),(225,239),(200,226) )

        ########
        # draw #
        ########

        # body
        self.c.create_polygon(bodyCoords, fill=self.bodyColor,
                           outline="black", width=2, tag = self.name)

        # legs
        self.c.create_line(rightlegCoords, width=2.5, tag = self.name)
        self.c.create_arc(rightleg1Coords,width=2.5,start=-90,extent=90,style=ARC, tag = self.name)
        self.c.create_line(rightleg2Coords,width=2, tag = self.name)
        
        self.c.create_line(leftlegCoords, width=2.5, tag = self.name)
        self.c.create_arc(leftleg1Coords,width=2.5,start=-90,extent=-90,style=ARC, tag = self.name)
        self.c.create_line(leftleg2Coords,width=2, tag = self.name)

        # arms

        self.c.create_arc((255,220),(282.5,230), start=180,extent=180,style=ARC,width=2, tag = self.name)
        self.c.create_arc((280.5,226.5),(289,215), start=90,extent=150,style=ARC,width=2, tag = self.name)
        self.c.create_arc((280.5,226.5),(297.5,216.5), start=180,extent=150,style=ARC,width=2, tag = self.name)
        self.c.create_arc((283,214),(305,234), start=-90,extent=-90,style=ARC,width=2, tag = self.name)
        self.c.create_arc((282.5,211.5),(290,237.5), start=-90,extent=-90,style=ARC,width=2, tag = self.name)

        
        self.c.create_arc((170,220),(142.5,230), start=180,extent=180,style=ARC,width=2, tag = self.name)
        self.c.create_arc((144.5,226.5),(136,215), start=-90,extent=150,style=ARC,width=2, tag = self.name)
        self.c.create_arc((144.5,226.5),(127.5,216.5), start=180,extent=150,style=ARC,width=2, tag = self.name)
        self.c.create_arc((142,214),(120,234), start=-90,extent=90,style=ARC,width=2, tag = self.name)
        self.c.create_arc((142.5,211.5),(135,237.5), start=-90,extent=90,style=ARC,width=2, tag = self.name)


        #body details
        self.c.create_line((175,219.5),(250.5,219.5), width=1.5, tag = self.name)
        self.c.create_line((167.5,232.5),(257.5,232.5), width=1.5, tag = self.name)
        self.c.create_line((157.5,249.5),(267.5,249.5), width=1.5, tag = self.name)
        self.c.create_line((212.5,232.5),(212.5,249.5), width=1, tag = self.name)
        self.c.create_line((180,232.5),(180,249.5), width=1, tag = self.name)
        self.c.create_line((245,232.5),(245,249.5), width=1, tag = self.name)
        self.c.create_line((190,219.5),(190,232.5), width=1, tag = self.name)
        self.c.create_line((235,219.5),(235,232.5), width=1, tag = self.name)

        #eyeball
        self.c.create_arc((195,180),(230,200),start=180,extent=359,style=CHORD,width=1,fill="white", tag = self.name)
        self.c.create_arc((210,182.5),(215,197.5),start=90,extent=359,style=PIESLICE,width=1,fill="black", tag = self.name)
        self.c.create_line((212.5,175),(212.5,180),width=1, tag = self.name)
        self.c.create_line((222.5,176),(220,181),width=1,smooth=1, tag = self.name)
        self.c.create_line((202.5,176),(205,181),width=1,smooth=1, tag = self.name)

        self.c.create_line((212.5,200),(212.5,204),width=1, tag = self.name)
        self.c.create_line((222.5,202.5),(220,199.5),width=1, tag = self.name)
        self.c.create_line((202.5,202.5),(205,199.5),width=1, tag = self.name)
        

        # Hat
        self.c.create_polygon(hatCoords, fill=self.accessoryColor, tag = self.name)
        self.c.create_line(hat2Coords, fill=self.accessoryColor, width=2.5, tag = self.name)


        #Bowtie
        self.c.create_oval(bowtieCoords, fill=self.accessoryColor, width=1.5, tag = self.name)
        self.c.create_polygon(bowtie2Coords, fill=self.accessoryColor, tag = self.name) 
            
        
        self.c.update()

    #####################################################################
    # moveLeft                                                          #
    #                                                                   #
    # purpose:                                                          #
    #     moves the genie to the left the specified distance            #
    # parameters:                                                       #
    #     dist       -- distance to move                                #
    #     prevDelay  -- amount of delay before the move (default of 0)  #
    #     afterDelay -- amount of delay after the move (default of 0)   #
    # return value: none                                                #
    #####################################################################
    def moveLeft(self, dist, prevDelay=0, afterDelay=0):
        self.center -= dist
        self.c.update()
        self.c.after(prevDelay)
        self.c.update()
        self.c.move(self.name, -dist,0)
        self.c.update()
        self.c.after(afterDelay)
        self.c.update()

    #####################################################################
    # moveRight                                                         #
    #                                                                   #
    # purpose:                                                          #
    #     moves the genie to the right the specified distance           #
    # parameters:                                                       #
    #     dist       -- distance to move                                #
    #     prevDelay  -- amount of delay before the move (default of 0)  #
    #     afterDelay -- amount of delay after the move (default of 0)   #
    # return value: none                                                #
    #####################################################################
    def moveRight(self, dist, prevDelay=0, afterDelay=0):
        self.moveLeft(-dist, prevDelay, afterDelay)

    #####################################################################
    # dance                                                             #
    #                                                                   #
    # purpose:                                                          #
    #     move the puppy to make a simple dance routine                 #
    # parameters:                                                       #
    #     times -- number of times to move randomly for the dance       #
    # return value: none                                                #
    #####################################################################
    def dance(self, times=50):
        for i in range(times):
            before = random.randrange(10,100)
            after = random.randrange(10,100)
            distance = random.randrange(-15,15)
            self.moveLeft(distance, prevDelay=before, afterDelay=after)
        
