################################################################################
#                             Bedroom                                          #
#                                                                              #
# PROGRAMMER:       Alvaro Espinoza                                            #
# CLASS:            CG120                                                      #
# ASSIGNMENT:       Assignment 7                                               #
# INSTRUCTOR:       Dean Zeller                                                #
# TA:               Robert Carver                                              #
# SUBMISSION DATE:  November 16, 2018                                          #
#                                                                              #
# DESCRIPTION:                                                                 #
# This program is a function that draws a bedroom scene on the canvas provided #
# as a parameter.                                                              #
#                                                                              #
# COPYRIGHT:                                                                   #
# This program is (c) 2018 Alvaro Espinoza and Dean Zeller. This is original   #
# work, without use of outside sources.                                        #
################################################################################





def background(c):
    c.create_rectangle((0,0),(800,300), fill="antique white")
    c.create_rectangle((0,300),(800,500), fill="burlywood3")
    c.create_line((0,350),(800,350),width=1)
    c.create_line((0,400),(800,400),width=1)
    c.create_line((0,450),(800,450),width=1)
    c.create_line((0,500),(800,500),width=1)
    c.create_line((200,300),(200,350),width=1)
    c.create_line((600,300),(600,350),width=1)
    c.create_line((400,350),(400,400),width=1)
    c.create_line((100,400),(100,450),width=1)
    c.create_line((500,400),(500,450),width=1)
    c.create_line((250,450),(250,500),width=1)
    c.create_line((600,450),(600,500),width=1)
