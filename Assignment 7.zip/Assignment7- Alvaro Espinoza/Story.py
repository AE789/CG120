################################################################################
#                            Bad Genie Wish                                    #
#                                                                              #
# PROGRAMMER:       Alvaro Espinoza                                            #
# CLASS:            CG120                                                      #
# ASSIGNMENT:       Assignment 7                                               #
# INSTRUCTOR:       Dean Zeller                                                #
# TA:               Robert Carver                                              #
# SUBMISSION DATE:  Friday, November 16th                                      #
#                                                                              #
# DESCRIPTION:                                                                 #
# This is the story of a boy who trusts a genie and gets granted a bad wish.   #
#                                                                              #
#                                                                              #
# EXTERNAL FILES:                                                              #
# This program references the following files for the story:                   #
#     Boy.py and Genie.py are used as the main characters, Background.py       #
#     serves as the story scenery, and Wish.py serves as a prop.               #
#                                                                              #
# COPYRIGHT:                                                                   #
# This program is (c) 2018 your-name and Dean Zeller. This is original         #
# work, without use of outside sources.                                        #
################################################################################
from tkinter import *
import random
from Boy import boy
from Genie import genie
from Background import background
from Wish import wish
c = Canvas(width=800,height=700,bg="white")
c.pack(expand=YES, fill=BOTH)

# draw scene
background(c)
c.update()
c.after(1000)
c.update()

# introduce main characters
c.create_text(200,50, text="Introducing Jimmy, an unsuspecting young man...", tag="annotation")
c.update()
c.after(3000)
c.update()
c.delete("annotation")
jimmy = boy(c, name="Jimmy")
jimmy.draw()
c.create_text(625,220, text="*sigh* If only I was rich, then I could do whatever I want", tag="annotation")
c.update()
c.after(4000)
c.update()
engelbert = genie(c, name="Engelbert", bodyColor="yellow", accessoryColor="black")
engelbert.draw()
engelbert.moveLeft(100, afterDelay=1000)
c.delete("annotation")
c.update()
c.after(1000)
c.update()


# dialog between both characters
for i in range(10):
    engelbert.moveRight(10)
    
c.create_text(300,50, text="Hey bro! I'm a genie I can give you whatever you want. Just choose wisely as you only get one wish.", tag="annotation")
c.update()
c.after(5000)
c.update()
c.delete("annotation")
c.update()
c.after(1000)
c.update()

c.create_text(625,220, text="Well, I want to be rich, you can do that right?", tag="annotation")
c.update()
c.after(4000)
c.update()
c.delete("annotation")
c.update()
c.after(1000)
c.update()

c.create_text(300,50, text="Duh, I'm all powerful, remember though, there is no reversing the wish.", tag="annotation")
c.update()
c.after(4000)
c.update()
c.delete("annotation")
c.update()
c.after(1000)
c.update()

c.create_text(625,220, text="Yeah whatever, just make me rich already!", tag="annotation")
c.update()
c.after(4000)
c.update()
c.delete("annotation")
c.update()
c.after(1000)
c.update()

c.create_text(300,50, text="OK, here you go.", tag="annotation")
c.update()
c.after(3000)
c.update()
c.delete("annotation")
c.update()
c.after(1000)
c.update()

engelbert.moveLeft(100, afterDelay=1000)
c.update()

for i in range(1):
    c.move("Engelbert",0,20)
    c.after(100)
    c.update()

#object appears
money = wish(c, name="Money")
money.draw()
c.update()
c.after(1000)
c.update()
for i in range(1):
    c.move("Money",0,-25)
    c.after(100)
    c.update()
for i in range(9):
    c.move("Money",25,0)
    c.after(100)
    c.update()

#more dialog between characters
c.create_text(625,220, text="Wait! I didn't ask for that! Also, why is it above me?!?", tag="annotation")
c.update()
c.after(4000)
c.update()
c.delete("annotation")
c.update()
c.after(1000)
c.update()

c.create_text(300,180, text="Ummm, I thought this was what you wanted?", tag="annotation")
c.update()
c.after(4000)
c.update()
c.delete("annotation")
c.update()
c.after(1000)
c.update()

#object is cloned and is moved
money2 = wish(c, name="Money2")
money2.draw()
c.update()
c.after(1000)
c.update()
for i in range(1):
    c.move("Money2",0,-25)
    c.after(100)
    c.update()
for i in range(9):
    c.move("Money2",25,0)
    c.after(100)
    c.update()

c.create_text(625,220, text="Wait stop! Please just change the wish.", tag="annotation")
c.update()
c.after(3000)
c.update()
c.delete("annotation")
c.update()
c.after(1000)
c.update()

c.create_text(300,180, text="Too late bro, just be happy you're gonna be rich lol.", tag="annotation")
c.update()
c.after(4000)
c.update()
c.delete("annotation")
c.update()
c.after(1000)
c.update()
    

money3 = wish(c, name="Money3")
money3.draw()
c.update()
c.after(1000)
c.update()
for i in range(1):
    c.move("Money3",0,-25)
    c.after(100)
    c.update()
for i in range(9):
    c.move("Money3",25,0)
    c.after(100)
    c.update()
    
for i in range(5):
    c.move("Money",0,20)
    c.after(200)
    c.update()

c.create_text(625,220, text="Heeeelllllp!", tag="annotation")
c.update()
c.after(2000)
c.update()
c.delete("annotation")
c.update()
c.after(1000)
c.update()

for i in range(10):
    c.move("Money",0,20)
    c.after(100)
    c.update()

for i in range(10):
    c.move("Money2",0,25)
    c.after(100)
    c.update()

for i in range(8):
    c.move("Money3",0,25)
    c.after(100)
    c.update()

engelbert.moveLeft(50, afterDelay=1000)

c.create_text(675,220, text="Jimmy is now dead. RIP", tag="annotation")
c.update()
c.after(4000)
c.update()
c.delete("annotation")
c.update()
c.after(1000)
c.update()

#boy is deleted
c.delete("Jimmy")
c.update()
c.after(1000)
c.update()

#genie has final say
c.create_text(300,50, text="Ah yes, looks like my work here is done. Time to go ruin more lives.", tag="annotation")
c.update()
c.after(4000)
c.update()
c.delete("annotation")
c.update()
c.after(500)
c.update()

c.create_text(300,50, text="But before I leave, I should celebrate with a dance.", tag="annotation")
c.update()
c.after(4000)
c.update()
c.delete("annotation")
c.update()
c.after(500)
c.update()

# end the story with a dance
engelbert.dance()

c.delete("Engelbert")
c.update()
c.after(1000)
c.update()

# roll credits
c.delete(ALL)
creditText="""
Bad Genie Wish
by
Alvaro Espinoza


Completed as part of a CG120 assignment.

       
PLOT and DIALOG
Alvaro Espinoza

SCENERY DESIGN
Alvaro Espinoza

CHARACTER DESIGN
Alvaro Espinoza

(c)2018 Alvaro Espinoza Productions, all rights reserved."""

credits = c.create_text(200,800,text=creditText, font=("Courier",9),
                        justify=CENTER)
for i in range(1300):
    c.move(credits,0,-1)
    c.after(10)
    c.update()


