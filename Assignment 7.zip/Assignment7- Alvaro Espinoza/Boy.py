################################################################################
#                               boy object                                     #
#                                                                              #
# PROGRAMMER:       Alvaro Espinoza                                            #      
# CLASS:            CG120                                                      #
# ASSIGNMENT:       Assignment 7                                               #
# INSTRUCTOR:       Dean Zeller                                                #
# TA:               Robert Carver                                              #
# SUBMISSION DATE:  November 16, 2018                                          #                                                                              #
# DESCRIPTION:                                                                 #
# This is the definition for a boy object.                                     #
#                                                                              #
# COPYRIGHT:                                                                   #
# This program is (c) 2018 Alvaro Espinoza and Dean Zeller. This is original   #
# work, without use of outside sources.                                        #
################################################################################
from tkinter import *
import random

class boy:


    #####################################################################
    # __init__                                                          #
    #                                                                   #
    # purpose:                                                          #
    #     initialize attributes to parameters                           #
    # parameters:                                                       #
    #     canvas -- the canvas to draw the boy                          #
    #     name   -- name of the boy, used as a tag for animation        #
    # return value: none                                                #
    #####################################################################
    
    def __init__ (self, canvas, name="Blank"):
        self.c = canvas
        self.name = name
        self.center = 0
        self.middle = 0
        self.name = name


    #####################################################################
    # draw                                                              #
    #                                                                   #
    # purpose:                                                          #
    #     draws the boy instance with its initial location and colors   #
    # parameters:                                                       #
    #     none                                                          #
    # return value: none                                                #
    #####################################################################
    def draw(self):
        # define coordinates
        # currently all coordinates are hardcoded
        self.center = 200
        self.middle = 112


        self.c.create_oval((375,200),(425,250),width=1, tag=self.name, fill="tan2")
        self.c.create_oval((390,220),(395,225),width=3, tag=self.name, fill="snow")
        self.c.create_oval((405,220),(410,225),width=3, tag=self.name, fill="snow")
        self.c.create_line((390,240),(410,240), tag=self.name)
        self.c.create_line((428,220),(428,230),width=5, tag=self.name, fill="tan2")
        self.c.create_line((372,220),(372,230),width=5, tag=self.name, fill="tan2")
        

        self.c.create_line((400,252),(400,310),width=7, fill="lime green", tag=self.name)
        self.c.create_line((398,265),(380,295),width=5, fill="lime green", tag=self.name)
        self.c.create_line((401,265),(420,295),width=5, fill="lime green", tag=self.name)
        self.c.create_line((398,310),(385,340),width=5, fill="deep sky blue", tag=self.name)
        self.c.create_line((401,310),(415,340),width=5, fill="deep sky blue", tag=self.name)
        self.c.create_line((387,342),(375,342),width=5, fill="gray3", tag=self.name)
        self.c.create_line((417,342),(405,342),width=5, fill="gray3", tag=self.name)
        

        self.c.create_arc((375,200),(428,225), fill="dodger blue", tag=self.name, start=-180, extent=-180, style=PIESLICE)
        self.c.create_line((360,215),(428,215),width=3, fill="dodger blue", tag=self.name)

