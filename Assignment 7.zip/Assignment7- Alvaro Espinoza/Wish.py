################################################################################
#                           wish movable object                                #
#                                                                              #
# PROGRAMMER:       Alvaro Espinoza                                            #      
# CLASS:            CG120                                                      #
# ASSIGNMENT:       Assignment 7                                               #
# INSTRUCTOR:       Dean Zeller                                                #
# TA:               Robert Carver                                              #
# SUBMISSION DATE:  November 16, 2018                                          #                                                                              #
# DESCRIPTION:                                                                 #
# This is the definition for a wish movable object.                            #
#                                                                              #
# COPYRIGHT:                                                                   #
# This program is (c) 2018 Alvaro Espinoza and Dean Zeller. This is original   #
# work, without use of outside sources.                                        #
################################################################################

from tkinter import *
import random

class wish:


    #####################################################################
    # __init__                                                          #
    #                                                                   #
    # purpose:                                                          #
    #     initialize attributes to parameters                           #
    # parameters:                                                       #
    #     canvas -- the canvas to draw the wish                         #
    #     name   -- name of the wish, used as a tag for animation       #
    # return value: none                                                #
    #####################################################################
    
    def __init__ (self, canvas, name="Blank", tag="money"):
        self.c = canvas
        self.name = name
        self.center = 0
        self.middle = 0
        self.name = name


    #####################################################################
    # draw                                                              #
    #                                                                   #
    # purpose:                                                          #
    #     draws the wish instance with its initial location and colors  #
    # parameters:                                                       #
    #     none                                                          #
    # return value: none                                                #
    #####################################################################
    def draw(self):
        # define coordinates
        # currently all coordinates are hardcoded
        self.center = 200
        self.middle = 112

        self.c.create_polygon((0,100),(100,120),(95,80),(10,65),(0,100), fill="yellow", width=2, tag=self.name, outline="black")
        self.c.create_polygon((10,65),(300,0),(370,15),(95,80),(10,65), fill="yellow", width=2, tag=self.name, outline="black")
        self.c.create_polygon((370,15),(375,45),(100,120),(95,80),(370,15), fill="yellow", width=2, tag=self.name, outline="black")








    #####################################################################
    # moveLeft                                                          #
    #                                                                   #
    # purpose:                                                          #
    #     moves the wish to the left the specified distance             #
    # parameters:                                                       #
    #     dist       -- distance to move                                #
    #     prevDelay  -- amount of delay before the move (default of 0)  #
    #     afterDelay -- amount of delay after the move (default of 0)   #
    # return value: none                                                #
    #####################################################################
    def moveLeft(self, dist, prevDelay=0, afterDelay=0):
        self.center -= dist
        self.c.update()
        self.c.after(prevDelay)
        self.c.update()
        self.c.move(self.name, -dist,0)
        self.c.update()
        self.c.after(afterDelay)
        self.c.update()
        
    #####################################################################
    # moveRight                                                         #
    #                                                                   #
    # purpose:                                                          #
    #     moves the wish to the right the specified distance            #
    # parameters:                                                       #
    #     dist       -- distance to move                                #
    #     prevDelay  -- amount of delay before the move (default of 0)  #
    #     afterDelay -- amount of delay after the move (default of 0)   #
    # return value: none                                                #
    #####################################################################
    def moveRight(self, dist, prevDelay=0, afterDelay=0):
        self.moveLeft(-dist, prevDelay, afterDelay)
